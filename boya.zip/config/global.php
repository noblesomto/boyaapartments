<?php


return [
    'site_name' => 'Boya Apartment',
    'site_title' => 'a Home away from Home',
    'admin_email' => 'noblesomto1@gmail.com',
    'admin_phone' => '08067976421',
    'tagLine' => 'Do the best'
];